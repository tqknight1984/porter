#!/usr/bin/python
#coding=utf-8
import sys
print sys.getdefaultencoding()